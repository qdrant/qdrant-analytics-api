# qdrant-analytics-events

This repository contains JSON schema defining analytics events raised by the Qdrant products.

It also contains a generator of type stubs for these events which can be used by the different products. Using these stubs ensures events raised comply with the schema via compile-time type verification.

You can find an [overview of the analytics events here](http://qdrant.github.io/qdrant-analytics-events/).

## Schemas

`/schemas` contains one JSON schema file per event, each named exactly according to the name of that event (case-sensitive).

## Guidelines for update/creating new event schema

- One schema per `.json`. The filename should match the event's name, including case.

- Each schema should contain an `event_name` property declared as an `enum` with a single value. This convention can be relied upon by consumers of stubs as a way to get the correct name to send for that event.

For example:

```json
"event_name": {
  "enum": ["Error"],
  "default": "Error"
},
```

- You must describe your event using `description` fields. Your audience might be unfamiliar with the codebase, or non-technical, so don't refer to code concepts and try to describe things in general but accurate terms. English grammar must be respected, in particular sentences must end with punctuation (eg a period).

- Lastly, edit `schemas/index.json` and add your event as reference in the `anyOf` list. This will add your event type to the union type containing all event types.

### Description examples

#### Events

```json
{
  "type": "object",
  "description": "Triggered when the user changed screen.",
  "properties": {
    "event_name": {
      "enum": ["Screen"],
      "default": "Screen"
    }
  }
}
```

#### Primitive properties

```json
"durationMs": {
  "description": "How long the screen was displayed for in milliseconds.",
  "type": "integer"
}
```

#### Enums

```json
"screenName": {
  "type": "string",
  "oneOf": [
    {"enum": ["Welcome"], "description": "The splash screen."},
  ]
}
```

> Do not use the syntatic sugar `const` as it doesn't work the Pydantic model generator for literals.

## TypeScript

### Installation

```shell
npm install ./lib/qdrant-qdrant-analytics-events-*.tgz
```

### Usage

```ts
import mixpanel from 'mixpanel-browser'; // example service
import { createEventTrackingHook } from '@qdrant/qdrant-analytics-events';

export const useEventTracking = createEventTrackingHook(
  // Argument types inferred from the TS definition
  (eventName, eventPayload) => {
    mixpanel.track(eventName, eventPayload);
  },
);
```

## Python

### Installation

```shell
.venv/bin/python -m poetry remove qdrant_analytics_events || true # remove previous version
.venv/bin/python -m poetry add pypi/qdrant_analytics_events-*.tar.gz # install new version
```

### Usage

```py
from mixpanel import Mixpanel
from qdrant_analytics_events.Login import Model as LoginEvent

def track_event():
  mp = Mixpanel("PROJECT_TOKEN")
  event = LoginEvent(authentication_type="Email")
  properties = event.model_dump({ exclude: "event_name" })
  _event_name = properties.event_name
  # Tracks an event, 'login', with distinct_id user_id
  mp.track(user_id, _event_name, properties)
```

## Development

### Scripts

- scripts/setup.sh: automated project setup both for local and CI
- scripts/build-typescript.sh: build TypeScript types from schemas
- scripts/build-pydantic.sh: build Pydantic models from schemas
- scripts/bump-version.sh: bump a patch version of packages (NPM + Poetry) and commit
- scripts/version-check.sh: checks that the latest Git tag is different than the version of the package (related to the previous point)
- scripts/release.sh: builds and creates a versioned Git tag

### Contributing

1. Open a Pull Request against `main` with event updates.
   - Manually bump the version in package.json and pyproject.toml (preferably patch instead of minor/major). It is recommended to use `scripts/bump-version.sh`.
   - Alternatively, skip a release by labeling the PR with [`non-release`](https://github.com/qdrant/qdrant-analytics-events/labels/non-release)
2. Upon merging, the release workflow creates a new Git Tag and GitHub release with artifacts.
3. Download the .tag(.gz) file(s) onto the project(s) where used as a package, e.g.: https://github.com/qdrant/qdrant-cloud-ui/tree/main/lib
4. Repeat when updates are necessary.
